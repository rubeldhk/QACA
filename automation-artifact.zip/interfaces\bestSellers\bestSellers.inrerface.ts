export interface verifyPage {
  pageName: string;
  title: string;
  url: string;
}

