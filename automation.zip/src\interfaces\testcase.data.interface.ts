export interface TestCaseData {
  tags: string;
  
  testCase: string;
  testDescription: string;
  testSummary: string;
}