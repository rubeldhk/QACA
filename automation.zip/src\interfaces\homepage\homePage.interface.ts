export interface helpAndAccountLinks {
    links: string[];
}


export interface NavDropdownItems {
        [key: string]: string[];
}

export interface FooterLinks {
    [key: string]: string;
}
export interface BloomexOtherDomainsLinks {
    [key: string]: string;
}

export interface HelpDeskChat {
    [key: string]: string;
}

export interface ElementExists {
    [key: string]: string;
}

export interface verifyBreadCrumbs {
    [key: string]: string;
}